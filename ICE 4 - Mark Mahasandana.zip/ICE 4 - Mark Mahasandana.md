```python
import pandas as pd
import matplotlib.pyplot as plt
```


```python
mooc = pd.read_csv("ICE4_Data.csv")
mooc
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>certified</th>
      <th>forum.posts</th>
      <th>grade</th>
      <th>assignment</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>no</td>
      <td>7</td>
      <td>3</td>
      <td>9</td>
    </tr>
    <tr>
      <th>1</th>
      <td>no</td>
      <td>7</td>
      <td>4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>yes</td>
      <td>191</td>
      <td>8</td>
      <td>19</td>
    </tr>
    <tr>
      <th>3</th>
      <td>yes</td>
      <td>130</td>
      <td>10</td>
      <td>18</td>
    </tr>
    <tr>
      <th>4</th>
      <td>yes</td>
      <td>135</td>
      <td>8</td>
      <td>18</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>yes</td>
      <td>88</td>
      <td>10</td>
      <td>13</td>
    </tr>
    <tr>
      <th>996</th>
      <td>yes</td>
      <td>153</td>
      <td>10</td>
      <td>19</td>
    </tr>
    <tr>
      <th>997</th>
      <td>no</td>
      <td>41</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>998</th>
      <td>no</td>
      <td>47</td>
      <td>6</td>
      <td>12</td>
    </tr>
    <tr>
      <th>999</th>
      <td>yes</td>
      <td>112</td>
      <td>8</td>
      <td>19</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 4 columns</p>
</div>




```python
mooc['certified'].value_counts()
```




    yes    725
    no     275
    Name: certified, dtype: int64




```python
mooc.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>forum.posts</th>
      <th>grade</th>
      <th>assignment</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1000.000000</td>
      <td>1000.00000</td>
      <td>1000.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>113.107000</td>
      <td>7.76500</td>
      <td>13.693000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>55.126477</td>
      <td>2.38232</td>
      <td>5.011973</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>1.00000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>72.750000</td>
      <td>8.00000</td>
      <td>12.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>118.500000</td>
      <td>8.00000</td>
      <td>15.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>160.000000</td>
      <td>9.00000</td>
      <td>17.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>200.000000</td>
      <td>10.00000</td>
      <td>20.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
import seaborn as sns
sns.pairplot(mooc, hue = "certified")

```




    <seaborn.axisgrid.PairGrid at 0x2671c1d6bb0>




    
![png](output_4_1.png)
    


What I see here is the corresponding data between X and Y Axis. I also see different style of graph presentation i.e. dots and curve graphs


```python
from sklearn.linear_model import LogisticRegression
```


```python
dummy = pd.get_dummies(mooc['certified'], prefix = 'certified')

dummy
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>certified_no</th>
      <th>certified_yes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>996</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>997</th>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>998</th>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>999</th>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 2 columns</p>
</div>




```python
moocD = pd.concat([mooc, dummy], axis=1)
moocD = moocD.drop(['certified', 'certified_no'], axis=1)
moocD
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>forum.posts</th>
      <th>grade</th>
      <th>assignment</th>
      <th>certified_yes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7</td>
      <td>3</td>
      <td>9</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>7</td>
      <td>4</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>191</td>
      <td>8</td>
      <td>19</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>130</td>
      <td>10</td>
      <td>18</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>135</td>
      <td>8</td>
      <td>18</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>88</td>
      <td>10</td>
      <td>13</td>
      <td>1</td>
    </tr>
    <tr>
      <th>996</th>
      <td>153</td>
      <td>10</td>
      <td>19</td>
      <td>1</td>
    </tr>
    <tr>
      <th>997</th>
      <td>41</td>
      <td>4</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>998</th>
      <td>47</td>
      <td>6</td>
      <td>12</td>
      <td>0</td>
    </tr>
    <tr>
      <th>999</th>
      <td>112</td>
      <td>8</td>
      <td>19</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 4 columns</p>
</div>




```python
Xs = moocD[["forum.posts", "grade", "assignment"]].to_numpy()
certified = moocD.loc[:,"certified_yes"].values.reshape(-1, 1)
```


```python
moocLogitModel1 = LogisticRegression()
moocLogitModel1.fit(Xs, certified)
```

    C:\Users\Sivakon.M\Anaconda3\lib\site-packages\sklearn\utils\validation.py:63: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      return f(*args, **kwargs)
    




    LogisticRegression()




```python
moocLogitModel1.intercept_
```




    array([-63.13291439])




```python
moocLogitModel1.coef_

```




    array([[0.62419697, 0.52270711, 0.85766257]])




```python
import statsmodels.api as sm

moocLogitModel2 = sm.Logit(certified, Xs)
moocLogitModel2Fit = moocLogitModel2.fit()
print(moocLogitModel2Fit.summary())
```

    Optimization terminated successfully.
             Current function value: 22.457768
             Iterations 7
                               Logit Regression Results                           
    ==============================================================================
    Dep. Variable:                      y   No. Observations:                 1000
    Model:                          Logit   Df Residuals:                      997
    Method:                           MLE   Df Model:                            2
    Date:                Wed, 20 Oct 2021   Pseudo R-squ.:                     inf
    Time:                        00:16:46   Log-Likelihood:                -22458.
    converged:                       True   LL-Null:                        0.0000
    Covariance Type:            nonrobust   LLR p-value:                     1.000
    ==============================================================================
                     coef    std err          z      P>|z|      [0.025      0.975]
    ------------------------------------------------------------------------------
    x1             0.0378      0.003     10.852      0.000       0.031       0.045
    x2            -0.3202      0.047     -6.879      0.000      -0.411      -0.229
    x3             0.0315      0.025      1.258      0.208      -0.018       0.081
    ==============================================================================
    

    C:\Users\Sivakon.M\Anaconda3\lib\site-packages\statsmodels\base\model.py:547: HessianInversionWarning: Inverting hessian failed, no bse or cov_params available
      warnings.warn('Inverting hessian failed, no bse or cov_params '
    C:\Users\Sivakon.M\Anaconda3\lib\site-packages\statsmodels\base\model.py:547: HessianInversionWarning: Inverting hessian failed, no bse or cov_params available
      warnings.warn('Inverting hessian failed, no bse or cov_params '
    C:\Users\Sivakon.M\Anaconda3\lib\site-packages\statsmodels\discrete\discrete_model.py:3500: RuntimeWarning: divide by zero encountered in double_scalars
      return 1 - self.llf/self.llnull
    


```python
from sklearn.tree import DecisionTreeClassifier

Xs_tree = mooc.drop('certified', axis = 1)
certified = mooc['certified']
```


```python
moocTreeModel = DecisionTreeClassifier()
moocTreeModel.fit(Xs_tree, certified)
```




    DecisionTreeClassifier()




```python
from sklearn import tree
text_representation = tree.export_text(moocTreeModel)
print(text_representation)
```

    |--- feature_0 <= 79.50
    |   |--- class: no
    |--- feature_0 >  79.50
    |   |--- feature_1 <= 7.50
    |   |   |--- class: no
    |   |--- feature_1 >  7.50
    |   |   |--- class: yes
    
    


```python
tree.plot_tree(moocTreeModel)
```




    [Text(133.92000000000002, 181.2, 'X[0] <= 79.5\ngini = 0.399\nsamples = 1000\nvalue = [275, 725]'),
     Text(66.96000000000001, 108.72, 'gini = 0.0\nsamples = 271\nvalue = [271, 0]'),
     Text(200.88000000000002, 108.72, 'X[1] <= 7.5\ngini = 0.011\nsamples = 729\nvalue = [4, 725]'),
     Text(133.92000000000002, 36.23999999999998, 'gini = 0.0\nsamples = 4\nvalue = [4, 0]'),
     Text(267.84000000000003, 36.23999999999998, 'gini = 0.0\nsamples = 725\nvalue = [0, 725]')]




    
![png](output_17_1.png)
    



```python
from sklearn.naive_bayes import GaussianNB

Xs_NB = mooc.drop('certified', axis = 1)
certified = mooc['certified']
```


```python
moocNBModel = GaussianNB()
moocNBModel.fit(Xs_NB, certified)
```




    GaussianNB()




```python
certified_pred = moocNBModel.predict(Xs_NB)
performance = [item in certified_pred for item in certified]
print('The accuracy is', sum(performance)/len(performance)*100, '%')
```

    The accuracy is 100.0 %
    


```python
from sklearn.model_selection import train_test_split

## For logistic regression
Xs_logit = moocD[["forum.posts", "grade", "assignment"]].to_numpy()
certified_logit = moocD.loc[:,"certified_yes"].values.reshape(-1, 1)
xs_logit_training, xs_logit_test, y_logit_training, y_logit_test = train_test_split(Xs_logit, certified_logit, test_size = 0.2)

## For decision tree and Naive Bayes
Xs_TNB = mooc.drop('certified', axis = 1)
certified_TNB = mooc['certified']
xs_TNB_training, xs_TNB_test, y_TNB_training, y_TNB_test = train_test_split(Xs_TNB, certified_TNB, test_size = 0.2)
```
