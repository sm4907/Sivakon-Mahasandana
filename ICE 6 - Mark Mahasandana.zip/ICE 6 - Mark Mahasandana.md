```python
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
```


```python
np.random.seed(123)

X = np.random.randn(200) + 1.5
res = 0.5 * np.random.randn(200)
y = 1 + 2 * X + res

twoDData = np.c_[X,y]

plt.scatter(twoDData[:, 0], twoDData[:, 1])
```




    <matplotlib.collections.PathCollection at 0x21c7f595940>




    
![png](output_1_1.png)
    



```python
from sklearn.decomposition import PCA

pca = PCA(n_components=2)
pca.fit(twoDData)
```




    PCA(n_components=2)




```python
print(pca.components_)
```

    [[-0.43316568 -0.90131431]
     [-0.90131431  0.43316568]]
    


```python
print(pca.explained_variance_)
```

    [5.75175781 0.04167795]
    


```python
pca = PCA(n_components=1)
pca.fit(twoDData)
twoDData_dr = pca.transform(twoDData)
print("original shape:   ", twoDData.shape)
print("transformed shape:", twoDData_dr.shape)
```

    original shape:    (200, 2)
    transformed shape: (200, 1)
    


```python
twoDData_new = pca.inverse_transform(twoDData_dr)
plt.scatter(twoDData[:, 0], twoDData[:, 1], alpha=0.5)
plt.scatter(twoDData_new[:, 0], twoDData_new[:, 1], alpha=0.8)
```




    <matplotlib.collections.PathCollection at 0x21c0229e5b0>




    
![png](output_6_1.png)
    



```python
ICEdata = pd.read_csv("ICE6_Data.csv")
ICEdata
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>prior_prob_count</th>
      <th>prior_percent_correct</th>
      <th>problems_attempted</th>
      <th>mean_correct</th>
      <th>mean_hint</th>
      <th>mean_attempt</th>
      <th>mean_confidence</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>172777</td>
      <td>650</td>
      <td>0.723077</td>
      <td>4</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.550159</td>
    </tr>
    <tr>
      <th>1</th>
      <td>175658</td>
      <td>1159</td>
      <td>0.800690</td>
      <td>22</td>
      <td>0.454545</td>
      <td>2.227273</td>
      <td>1.227273</td>
      <td>0.437515</td>
    </tr>
    <tr>
      <th>2</th>
      <td>175669</td>
      <td>1239</td>
      <td>0.656981</td>
      <td>11</td>
      <td>0.636364</td>
      <td>1.363636</td>
      <td>1.727273</td>
      <td>0.511060</td>
    </tr>
    <tr>
      <th>3</th>
      <td>176151</td>
      <td>1246</td>
      <td>0.729535</td>
      <td>16</td>
      <td>0.750000</td>
      <td>0.562500</td>
      <td>1.187500</td>
      <td>0.491578</td>
    </tr>
    <tr>
      <th>4</th>
      <td>176165</td>
      <td>1299</td>
      <td>0.568129</td>
      <td>6</td>
      <td>0.333333</td>
      <td>2.166667</td>
      <td>2.000000</td>
      <td>0.409887</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>337</th>
      <td>253464</td>
      <td>9</td>
      <td>0.222222</td>
      <td>23</td>
      <td>0.782609</td>
      <td>0.000000</td>
      <td>1.347826</td>
      <td>0.602103</td>
    </tr>
    <tr>
      <th>338</th>
      <td>253517</td>
      <td>6</td>
      <td>0.833333</td>
      <td>16</td>
      <td>0.562500</td>
      <td>0.562500</td>
      <td>2.062500</td>
      <td>0.571269</td>
    </tr>
    <tr>
      <th>339</th>
      <td>255494</td>
      <td>12</td>
      <td>0.750000</td>
      <td>3</td>
      <td>0.666667</td>
      <td>0.666667</td>
      <td>1.333333</td>
      <td>0.563379</td>
    </tr>
    <tr>
      <th>340</th>
      <td>256227</td>
      <td>84</td>
      <td>0.678571</td>
      <td>3</td>
      <td>0.333333</td>
      <td>1.666667</td>
      <td>1.333333</td>
      <td>0.567501</td>
    </tr>
    <tr>
      <th>341</th>
      <td>257289</td>
      <td>20</td>
      <td>1.000000</td>
      <td>4</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.439283</td>
    </tr>
  </tbody>
</table>
<p>342 rows × 8 columns</p>
</div>




```python
ICEdata_noid = ICEdata.drop(['id'], axis = 1)
icepca = PCA(n_components=7)
icepca.fit(ICEdata_noid)

print("The principal components are:")
print(icepca.components_)
print("The explained variances are:")
print(icepca.explained_variance_)
```

    The principal components are:
    [[ 9.99998379e-01  3.25231653e-05  1.72229676e-03  6.65415156e-05
       4.97054823e-04  1.49367002e-04  1.15030348e-05]
     [-1.73541120e-03  1.03037706e-03  9.99602228e-01  2.30861751e-03
       2.23020180e-02  1.69662730e-02 -8.64582845e-04]
     [-3.87330335e-04 -3.27396081e-02 -2.70451869e-02 -1.24635620e-01
       6.73010236e-01  7.27812593e-01  2.92226368e-03]
     [ 2.29120283e-04  3.26414469e-02  3.68040760e-03  1.78860696e-01
      -7.05688901e-01  6.84765009e-01  5.46329794e-03]
     [ 1.63571033e-04 -1.96336169e-01  6.70115719e-03 -9.52166155e-01
      -2.19898499e-01  3.19977181e-02 -7.35362922e-02]
     [ 1.91456302e-05 -9.79282671e-01  7.60612436e-04  1.99617334e-01
      -2.17110326e-03 -7.96442781e-03  3.30097853e-02]
     [ 1.73255132e-06 -1.78647923e-02 -1.39538358e-03  7.74726598e-02
       1.42375081e-02  3.24800341e-03 -9.96726458e-01]]
    The explained variances are:
    [1.01909636e+05 9.65917304e+01 8.07223611e-01 4.21069102e-01
     4.13364216e-02 1.60996431e-02 1.08938450e-02]
    


```python
icedata_dr = icepca.transform(ICEdata_noid)
plt.scatter(icedata_dr[:,0], icedata_dr[:,1])
```




    <matplotlib.collections.PathCollection at 0x21c027c9a60>




    
![png](output_9_1.png)
    



```python
from sklearn.cluster import KMeans

kmeans = KMeans(n_clusters=3)
kmeans.fit(icedata_dr)
cluster_kmeans = kmeans.predict(icedata_dr)

plt.scatter(icedata_dr[:, 0], icedata_dr[:, 1], c=cluster_kmeans, cmap='viridis')
```
