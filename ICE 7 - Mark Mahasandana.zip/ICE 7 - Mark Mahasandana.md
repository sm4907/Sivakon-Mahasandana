```python
import pandas as pd 
import matplotlib.pyplot as plt 
```


```python
DATA = pd.read_csv("AC_3_Data.csv")
DATA
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>University ID</th>
      <th>Control</th>
      <th>Location</th>
      <th>SAT AVG</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>110404</td>
      <td>1</td>
      <td>1</td>
      <td>1534</td>
    </tr>
    <tr>
      <th>1</th>
      <td>144050</td>
      <td>1</td>
      <td>1</td>
      <td>1504</td>
    </tr>
    <tr>
      <th>2</th>
      <td>166683</td>
      <td>1</td>
      <td>1</td>
      <td>1503</td>
    </tr>
    <tr>
      <th>3</th>
      <td>166027</td>
      <td>1</td>
      <td>1</td>
      <td>1501</td>
    </tr>
    <tr>
      <th>4</th>
      <td>130794</td>
      <td>1</td>
      <td>1</td>
      <td>1497</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>194</th>
      <td>117946</td>
      <td>1</td>
      <td>1</td>
      <td>1202</td>
    </tr>
    <tr>
      <th>195</th>
      <td>187967</td>
      <td>2</td>
      <td>3</td>
      <td>1200</td>
    </tr>
    <tr>
      <th>196</th>
      <td>198516</td>
      <td>1</td>
      <td>2</td>
      <td>1200</td>
    </tr>
    <tr>
      <th>197</th>
      <td>136950</td>
      <td>1</td>
      <td>2</td>
      <td>1199</td>
    </tr>
    <tr>
      <th>198</th>
      <td>221759</td>
      <td>2</td>
      <td>1</td>
      <td>1199</td>
    </tr>
  </tbody>
</table>
<p>199 rows × 4 columns</p>
</div>




```python
DATA['University ID'] = 1
DATA
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>University ID</th>
      <th>Control</th>
      <th>Location</th>
      <th>SAT AVG</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1534</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1504</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1503</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1501</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1497</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>194</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1202</td>
    </tr>
    <tr>
      <th>195</th>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>1200</td>
    </tr>
    <tr>
      <th>196</th>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>1200</td>
    </tr>
    <tr>
      <th>197</th>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>1199</td>
    </tr>
    <tr>
      <th>198</th>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>1199</td>
    </tr>
  </tbody>
</table>
<p>199 rows × 4 columns</p>
</div>




```python
DATA.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>University ID</th>
      <th>Control</th>
      <th>Location</th>
      <th>SAT AVG</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>199.0</td>
      <td>199.000000</td>
      <td>199.000000</td>
      <td>199.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1.0</td>
      <td>1.286432</td>
      <td>1.628141</td>
      <td>1306.869347</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.0</td>
      <td>0.453234</td>
      <td>0.817987</td>
      <td>85.582986</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.0</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1199.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.0</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1235.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1.0</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1289.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>1.0</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>1365.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1.0</td>
      <td>2.000000</td>
      <td>4.000000</td>
      <td>1534.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
DATA['-Mean'] = DATA['SAT AVG'] - 1307
DATA
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>University ID</th>
      <th>Control</th>
      <th>Location</th>
      <th>SAT AVG</th>
      <th>-Mean</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1534</td>
      <td>227</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1504</td>
      <td>197</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1503</td>
      <td>196</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1501</td>
      <td>194</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1497</td>
      <td>190</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>194</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1202</td>
      <td>-105</td>
    </tr>
    <tr>
      <th>195</th>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>1200</td>
      <td>-107</td>
    </tr>
    <tr>
      <th>196</th>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>1200</td>
      <td>-107</td>
    </tr>
    <tr>
      <th>197</th>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>1199</td>
      <td>-108</td>
    </tr>
    <tr>
      <th>198</th>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>1199</td>
      <td>-108</td>
    </tr>
  </tbody>
</table>
<p>199 rows × 5 columns</p>
</div>




```python
DATA['-SAT AVG F'] = DATA['-Mean'] / 86
DATA
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>University ID</th>
      <th>Control</th>
      <th>Location</th>
      <th>SAT AVG</th>
      <th>-Mean</th>
      <th>-SAT AVG F</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1534</td>
      <td>227</td>
      <td>2.639535</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1504</td>
      <td>197</td>
      <td>2.290698</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1503</td>
      <td>196</td>
      <td>2.279070</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1501</td>
      <td>194</td>
      <td>2.255814</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1497</td>
      <td>190</td>
      <td>2.209302</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>194</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1202</td>
      <td>-105</td>
      <td>-1.220930</td>
    </tr>
    <tr>
      <th>195</th>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>1200</td>
      <td>-107</td>
      <td>-1.244186</td>
    </tr>
    <tr>
      <th>196</th>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>1200</td>
      <td>-107</td>
      <td>-1.244186</td>
    </tr>
    <tr>
      <th>197</th>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>1199</td>
      <td>-108</td>
      <td>-1.255814</td>
    </tr>
    <tr>
      <th>198</th>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>1199</td>
      <td>-108</td>
      <td>-1.255814</td>
    </tr>
  </tbody>
</table>
<p>199 rows × 6 columns</p>
</div>




```python
DATA
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>University ID</th>
      <th>Control</th>
      <th>Location</th>
      <th>SAT AVG</th>
      <th>-Mean</th>
      <th>-SAT AVG F</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1534</td>
      <td>227</td>
      <td>2.639535</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1504</td>
      <td>197</td>
      <td>2.290698</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1503</td>
      <td>196</td>
      <td>2.279070</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1501</td>
      <td>194</td>
      <td>2.255814</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1497</td>
      <td>190</td>
      <td>2.209302</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>194</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1202</td>
      <td>-105</td>
      <td>-1.220930</td>
    </tr>
    <tr>
      <th>195</th>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>1200</td>
      <td>-107</td>
      <td>-1.244186</td>
    </tr>
    <tr>
      <th>196</th>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>1200</td>
      <td>-107</td>
      <td>-1.244186</td>
    </tr>
    <tr>
      <th>197</th>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>1199</td>
      <td>-108</td>
      <td>-1.255814</td>
    </tr>
    <tr>
      <th>198</th>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>1199</td>
      <td>-108</td>
      <td>-1.255814</td>
    </tr>
  </tbody>
</table>
<p>199 rows × 6 columns</p>
</div>




```python
DATA_noid = DATA.drop(['University ID', 'SAT AVG', '-Mean'], axis =1)
DATA_noid
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Control</th>
      <th>Location</th>
      <th>-SAT AVG F</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>1</td>
      <td>2.639535</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1</td>
      <td>2.290698</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>1</td>
      <td>2.279070</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
      <td>2.255814</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>1</td>
      <td>2.209302</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>194</th>
      <td>1</td>
      <td>1</td>
      <td>-1.220930</td>
    </tr>
    <tr>
      <th>195</th>
      <td>2</td>
      <td>3</td>
      <td>-1.244186</td>
    </tr>
    <tr>
      <th>196</th>
      <td>1</td>
      <td>2</td>
      <td>-1.244186</td>
    </tr>
    <tr>
      <th>197</th>
      <td>1</td>
      <td>2</td>
      <td>-1.255814</td>
    </tr>
    <tr>
      <th>198</th>
      <td>2</td>
      <td>1</td>
      <td>-1.255814</td>
    </tr>
  </tbody>
</table>
<p>199 rows × 3 columns</p>
</div>




```python
from sklearn.decomposition import PCA
```


```python
DATApca = PCA(n_components=3)
DATApca.fit(DATA_noid)

print("The principal components are:")
print(DATApca.components_)
print("The explanied variances are:")
print(DATApca.explained_variance_)
```

    The principal components are:
    [[-0.19933164  0.00217916  0.97992966]
     [ 0.07317387  0.99723875  0.01266696]
     [ 0.97719623 -0.07423018  0.1989407 ]]
    The explanied variances are:
    [1.02424074 0.67187377 0.16873514]
    


```python
import matplotlib.pyplot as plt
import numpy as np

PC_values = np.arange(DATApca.n_components_) + 1
plt.plot(PC_values, DATApca.explained_variance_ratio_, 'o-', linewidth=2, color='blue')
plt.title('Scree Plot')
plt.xlabel('Principal Component')
plt.ylabel('Variance Explained')
plt.show()
```


    
![png](output_10_0.png)
    



```python
print(DATApca.explained_variance_ratio_)
```

    [0.54923502 0.36028308 0.0904819 ]
    

Based on the extract percentage of total variance , we can see that the first principal component explains 54.92% of the total variation in the dataset. The second principal component explains 36.02% of the total variation. Lastly, the third principal component explains 9.04%. Based on the finding, it is obvious that the first and second principal components represent majority of the dataset. 


```python
pca = PCA(n_components=2)
pca.fit(DATA)
DATA_dr = pca.transform(DATA)
print("original shape:  ", DATA.shape)
print("transformed shape:", DATA_dr.shape)
```

    original shape:   (199, 6)
    transformed shape: (199, 2)
    


```python
DATA_dr = DATApca.transform(DATA_noid)
plt.scatter(DATA_dr[:,0], DATA_dr[:,1])
```




    <matplotlib.collections.PathCollection at 0x24dbf75d850>




    
![png](output_14_1.png)
    



```python
from sklearn.cluster import KMeans

kmeans = KMeans(n_clusters=3)
kmeans.fit(DATA_dr)
cluster_kmeans = kmeans.predict(DATA_dr)

plt.scatter(DATA_dr[:, 0], DATA_dr[:,1], c=cluster_kmeans, cmap='viridis')
```




    <matplotlib.collections.PathCollection at 0x24dbfa96b50>




    
![png](output_15_1.png)
    

