```python
import networkx as nx
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
```


```python
SNAdata = pd.read_csv("ICE8_Data.csv", index_col = 0)
G = nx.Graph(SNAdata)
```


```python
nx.draw (G, with_labels = True)
```


    
![png](output_2_0.png)
    



```python
pip install decorator==5.0.9
```

    Collecting decorator==5.0.9
      Downloading decorator-5.0.9-py3-none-any.whl (8.9 kB)
    Installing collected packages: decorator
      Attempting uninstall: decorator
        Found existing installation: decorator 5.0.6
        Uninstalling decorator-5.0.6:
          Successfully uninstalled decorator-5.0.6
    Successfully installed decorator-5.0.9
    Note: you may need to restart the kernel to use updated packages.
    


```python
density = nx.density(G)

print('The edge density is: %.3f' % (density))
```

    The edge density is: 0.415
    


```python
degree = nx.degree(G)
degree
```




    DegreeView({'Nicolas Dussaillant': 3, 'Ming Chen': 5, 'Rebecca': 9, 'Nikita Tejwani': 8, 'Simon Chen': 3, 'Pooja Addla': 12, 'honglin': 4, 'Karl': 4, 'sicheng xu': 11, 'Jianan Dingqian': 10, 'Siyu Lin': 12, 'Ziqing Yuan': 11, 'Jingfei Chen': 8, 'Mina Choi': 7, 'Cleo You': 2, 'Deji': 6, 'Kan Yamane': 10, 'YUNWEI ZHANG': 11, 'Madeline': 6})




```python
pd.DataFrame(degree)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Nicolas Dussaillant</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Ming Chen</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rebecca</td>
      <td>9</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Nikita Tejwani</td>
      <td>8</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Simon Chen</td>
      <td>3</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Pooja Addla</td>
      <td>12</td>
    </tr>
    <tr>
      <th>6</th>
      <td>honglin</td>
      <td>4</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Karl</td>
      <td>4</td>
    </tr>
    <tr>
      <th>8</th>
      <td>sicheng xu</td>
      <td>11</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Jianan Dingqian</td>
      <td>10</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Siyu Lin</td>
      <td>12</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Ziqing Yuan</td>
      <td>11</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Jingfei Chen</td>
      <td>8</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Mina Choi</td>
      <td>7</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Cleo You</td>
      <td>2</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Deji</td>
      <td>6</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Kan Yamane</td>
      <td>10</td>
    </tr>
    <tr>
      <th>17</th>
      <td>YUNWEI ZHANG</td>
      <td>11</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Madeline</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>




```python
close = nx.closeness_centrality(G)
pd.DataFrame.from_dict(close, orient = 'index')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Nicolas Dussaillant</th>
      <td>0.529412</td>
    </tr>
    <tr>
      <th>Ming Chen</th>
      <td>0.514286</td>
    </tr>
    <tr>
      <th>Rebecca</th>
      <td>0.642857</td>
    </tr>
    <tr>
      <th>Nikita Tejwani</th>
      <td>0.620690</td>
    </tr>
    <tr>
      <th>Simon Chen</th>
      <td>0.428571</td>
    </tr>
    <tr>
      <th>Pooja Addla</th>
      <td>0.750000</td>
    </tr>
    <tr>
      <th>honglin</th>
      <td>0.500000</td>
    </tr>
    <tr>
      <th>Karl</th>
      <td>0.500000</td>
    </tr>
    <tr>
      <th>sicheng xu</th>
      <td>0.692308</td>
    </tr>
    <tr>
      <th>Jianan Dingqian</th>
      <td>0.666667</td>
    </tr>
    <tr>
      <th>Siyu Lin</th>
      <td>0.720000</td>
    </tr>
    <tr>
      <th>Ziqing Yuan</th>
      <td>0.692308</td>
    </tr>
    <tr>
      <th>Jingfei Chen</th>
      <td>0.529412</td>
    </tr>
    <tr>
      <th>Mina Choi</th>
      <td>0.529412</td>
    </tr>
    <tr>
      <th>Cleo You</th>
      <td>0.367347</td>
    </tr>
    <tr>
      <th>Deji</th>
      <td>0.486486</td>
    </tr>
    <tr>
      <th>Kan Yamane</th>
      <td>0.666667</td>
    </tr>
    <tr>
      <th>YUNWEI ZHANG</th>
      <td>0.692308</td>
    </tr>
    <tr>
      <th>Madeline</th>
      <td>0.545455</td>
    </tr>
  </tbody>
</table>
</div>




```python
between = nx.betweenness_centrality(G)
pd.DataFrame.from_dict(between, orient = 'index')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Nicolas Dussaillant</th>
      <td>0.028494</td>
    </tr>
    <tr>
      <th>Ming Chen</th>
      <td>0.043542</td>
    </tr>
    <tr>
      <th>Rebecca</th>
      <td>0.029879</td>
    </tr>
    <tr>
      <th>Nikita Tejwani</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>Simon Chen</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>Pooja Addla</th>
      <td>0.363663</td>
    </tr>
    <tr>
      <th>honglin</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>Karl</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>sicheng xu</th>
      <td>0.037340</td>
    </tr>
    <tr>
      <th>Jianan Dingqian</th>
      <td>0.042367</td>
    </tr>
    <tr>
      <th>Siyu Lin</th>
      <td>0.092655</td>
    </tr>
    <tr>
      <th>Ziqing Yuan</th>
      <td>0.037340</td>
    </tr>
    <tr>
      <th>Jingfei Chen</th>
      <td>0.007096</td>
    </tr>
    <tr>
      <th>Mina Choi</th>
      <td>0.019367</td>
    </tr>
    <tr>
      <th>Cleo You</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>Deji</th>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>Kan Yamane</th>
      <td>0.042367</td>
    </tr>
    <tr>
      <th>YUNWEI ZHANG</th>
      <td>0.037340</td>
    </tr>
    <tr>
      <th>Madeline</th>
      <td>0.087831</td>
    </tr>
  </tbody>
</table>
</div>




```python
from networkx.algorithms.community.modularity_max import greedy_modularity_communities

c = list(greedy_modularity_communities(G))

print(len(c))
```

    2
    


```python
community_0 = sorted(c[0])
community_1 = sorted(c[1])


print(community_0)
print(community_1)
```

    ['Deji', 'Jianan Dingqian', 'Jingfei Chen', 'Kan Yamane', 'Mina Choi', 'Nicolas Dussaillant', 'Nikita Tejwani', 'Rebecca', 'Simon Chen', 'Siyu Lin', 'YUNWEI ZHANG', 'Ziqing Yuan', 'sicheng xu']
    ['Cleo You', 'Karl', 'Madeline', 'Ming Chen', 'Pooja Addla', 'honglin']
    


```python
np.random.seed(123)
pos = nx.spring_layout(G)
nx.draw_networkx_nodes(G, pos = pos, nodelist=community_0, node_color='green', label = True)
nx.draw_networkx_nodes(G, pos = pos, nodelist=community_1, node_color='red', label = True)
nx.draw_networkx_edges(G, pos = pos, width = 0.2)
nx.draw_networkx_labels(G, pos=pos)
plt.show()
```


    
![png](output_11_0.png)
    



```python
nx.draw_networkx_nodes(G, pos = pos, nodelist = dict(degree).keys(), node_size = [v * 50 for v in dict(degree).values()], label = True)
nx.draw_networkx_edges(G, pos = pos, width = 0.2)
nx.draw_networkx_labels(G, pos=pos)
plt.show()
```


    
![png](output_12_0.png)
    



```python
eWeight = nx.get_edge_attributes(G,'weight')

nx.draw_networkx_nodes(G, pos = pos, nodelist = dict(degree).keys(), node_size = [v * 50 for v in dict(degree).values()], label = True)
nx.draw_networkx_edges(G,pos, width = [5**e/10 for e in eWeight.values()])
nx.draw_networkx_labels(G, pos=pos)

plt.show()
```


    
![png](output_13_0.png)
    



```python
community_0_degree = {c: dict(degree)[c] for c in community_0}
community_1_degree = {c: dict(degree)[c] for c in community_1}

nx.draw_networkx_nodes(G, pos = pos, 
                       nodelist=community_0,
                       node_color='green',
                       node_size = [v * 50 for v in community_0_degree.values()],
                       label = True)

nx.draw_networkx_nodes(G, pos = pos,
                       nodelist=community_1,
                       node_size = [v * 50 for v in community_1_degree.values()],
                       node_color='red', label = True)

nx.draw_networkx_edges(G,pos, width = [5**e/10 for e in eWeight.values()])

nx.draw_networkx_labels(G, pos=pos)

plt.show()
```


    
![png](output_14_0.png)
    

