In this assignment, I decided to collect the socal analysis network data of common (mutual) friends contact on Facebook. The data is derived from 10 nicknames of my actual friends. Kindly note that this dataset is fictional with sole purpose of this assignment. According to the dataset, Number 1 stands for being friend on Facebook and 0 stands for not being friend on Facebook. Before inserting the dataset to Jupyter, I have double checked the symetric of the data accordingly. The SNA data is being stored by adjacency matrix method. 


```python
import networkx as nx
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
```


```python
Data = pd.read_csv("ACA_4_Data.csv")
Data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>Chris</th>
      <th>Teddy</th>
      <th>Rit</th>
      <th>Tin</th>
      <th>Man</th>
      <th>Joyce</th>
      <th>Jas</th>
      <th>Bill</th>
      <th>Cher</th>
      <th>Win</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Chris</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Teddy</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rit</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Tin</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Man</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Joyce</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Jas</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Bill</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Cher</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Win</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



Due to the techinical issue on Jupyter, I have talked to Professor Liu and he suggested me to use Gephi as an alternative channel to conduct my social network analysis research. 


```python
from IPython import display
display.Image("./ACA4_Gephi_Data.png")
```




    
![png](output_4_0.png)
    



The graphic has 10 nodes and 48 edges. From the graphic, you can see the higher degree nodes in the middle. The betweenness centrality is determine by size of the circle. Man has the maximum value of betweenness centrality follows by Bill and Tin. The diameter value is 3, radius is 2, and average path length is 1.49. The diagram has two communities representing by colors: green and pink. Pink community represents 60% and green community represents 40% of the total modularity class. The modularity  is 0.135.
