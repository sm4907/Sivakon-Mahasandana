```python
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
```


```python
from sklearn.datasets import make_blobs # import make_blobs to help us simulate some data

twoDData, cluster_true = make_blobs(n_samples=300, centers=4,
                       cluster_std=0.50, random_state=0)

print("Here are the first 10 rows of twoDData:")
print(twoDData[:10])
print("Here are the true labels for each observation. But we don't need it.")
print(cluster_true[:10])
```

    Here are the first 10 rows of twoDData:
    [[ 1.03992529  1.92991009]
     [-1.38609104  7.48059603]
     [ 1.12538917  4.96698028]
     [-1.05688956  7.81833888]
     [ 1.4020041   1.726729  ]
     [ 3.20722587  0.36765575]
     [-1.76133611  1.81716162]
     [ 1.34081536  4.36827878]
     [-0.37881944  8.33265721]
     [-0.80062564  8.52294205]]
    Here are the true labels for each observation. But we don't need it.
    [1 3 0 3 1 1 2 0 3 3]
    


```python
plt.scatter(twoDData[:, 0], twoDData[:, 1]);
```


    
![png](output_2_0.png)
    



```python
from sklearn.cluster import KMeans
```


```python
kmeans = KMeans(n_clusters=4)
kmeans.fit(twoDData)
cluster_kmeans = kmeans.predict(twoDData)
```


```python
plt.scatter(twoDData[:, 0], twoDData[:, 1], c=cluster_kmeans, cmap='viridis')

centers = kmeans.cluster_centers_

plt.scatter(centers[:, 0], centers[:, 1], c='black', s=200, alpha=0.5);

```


    
![png](output_5_0.png)
    



```python
from sklearn.metrics import silhouette_score

silhouetteScore = silhouette_score(twoDData, cluster_kmeans, metric='euclidean')

print('Silhouetter Score:', silhouetteScore)
```

    Silhouetter Score: 0.7356713838266389
    


```python
conda install -c conda-forge yellowbrick
```

    Collecting package metadata (current_repodata.json): ...working... done
    Solving environment: ...working... done
    
    ## Package Plan ##
    
      environment location: C:\Users\Sivakon.M\Anaconda3
    
      added / updated specs:
        - yellowbrick
    
    
    The following packages will be downloaded:
    
        package                    |            build
        ---------------------------|-----------------
        conda-4.10.3               |   py38haa244fe_3         3.1 MB  conda-forge
        ------------------------------------------------------------
                                               Total:         3.1 MB
    
    The following packages will be UPDATED:
    
      conda                               4.10.3-py38haa244fe_2 --> 4.10.3-py38haa244fe_3
    
    
    
    Downloading and Extracting Packages
    
    conda-4.10.3         | 3.1 MB    |            |   0% 
    conda-4.10.3         | 3.1 MB    |            |   1% 
    conda-4.10.3         | 3.1 MB    | ####8      |  49% 
    conda-4.10.3         | 3.1 MB    | ########## | 100% 
    conda-4.10.3         | 3.1 MB    | ########## | 100% 
    Preparing transaction: ...working... done
    Verifying transaction: ...working... done
    Executing transaction: ...working... done
    
    Note: you may need to restart the kernel to use updated packages.
    


```python
from yellowbrick.cluster import SilhouetteVisualizer
```


```python
smodel = KMeans(n_clusters=4)
visualizer = SilhouetteVisualizer(smodel, colors='yellowbrick')
```


```python
visualizer.fit(twoDData)
visualizer.show()
```


    
![png](output_10_0.png)
    





    <AxesSubplot:title={'center':'Silhouette Plot of KMeans Clustering for 300 Samples in 4 Centers'}, xlabel='silhouette coefficient values', ylabel='cluster label'>




```python
from yellowbrick.cluster import silhouette_visualizer
silhouette_visualizer(kmeans, twoDData, colors='yellowbrick')
```


    
![png](output_11_0.png)
    





    SilhouetteVisualizer(ax=<AxesSubplot:title={'center':'Silhouette Plot of KMeans Clustering for 300 Samples in 4 Centers'}, xlabel='silhouette coefficient values', ylabel='cluster label'>,
                         colors='yellowbrick', estimator=KMeans(n_clusters=4))




```python
motivation = pd.read_csv("ICE5_Data.csv")
motivation
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>motivation1</th>
      <th>motivation2</th>
      <th>motivation3</th>
      <th>motivation4</th>
      <th>motivation5</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10005216</td>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>10033216</td>
      <td>3</td>
      <td>NaN</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10004216</td>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>10008216</td>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>10026216</td>
      <td>3</td>
      <td>NaN</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>10014216</td>
      <td>2</td>
      <td>NaN</td>
      <td>2</td>
      <td>NaN</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>10021216</td>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>10013216</td>
      <td>2</td>
      <td>NaN</td>
      <td>2</td>
      <td>NaN</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>10035216</td>
      <td>2</td>
      <td>3.0</td>
      <td>2</td>
      <td>3.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10015216</td>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>10031216</td>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>11</th>
      <td>10007216</td>
      <td>2</td>
      <td>1.0</td>
      <td>2</td>
      <td>1.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>10010216</td>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>13</th>
      <td>10020216</td>
      <td>2</td>
      <td>3.0</td>
      <td>2</td>
      <td>3.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>10002216</td>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>10011216</td>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16</th>
      <td>10023216</td>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>10028216</td>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>10028216</td>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>10034216</td>
      <td>3</td>
      <td>2.0</td>
      <td>3</td>
      <td>2.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>20</th>
      <td>10003216</td>
      <td>2</td>
      <td>NaN</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>21</th>
      <td>10029216</td>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>22</th>
      <td>10022216</td>
      <td>1</td>
      <td>3.0</td>
      <td>1</td>
      <td>3.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>23</th>
      <td>10006216</td>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>24</th>
      <td>10009216</td>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>25</th>
      <td>10018216</td>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>26</th>
      <td>10018216</td>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>27</th>
      <td>10018216</td>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>28</th>
      <td>10018216</td>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>29</th>
      <td>10018216</td>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>30</th>
      <td>10018216</td>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>31</th>
      <td>10018216</td>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>32</th>
      <td>10018216</td>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>33</th>
      <td>10027216</td>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>34</th>
      <td>10025216</td>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>35</th>
      <td>10019216</td>
      <td>1</td>
      <td>NaN</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>36</th>
      <td>10032216</td>
      <td>3</td>
      <td>NaN</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>37</th>
      <td>10017216</td>
      <td>3</td>
      <td>NaN</td>
      <td>3</td>
      <td>NaN</td>
      <td>3.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
motivationNA = motivation.dropna()
motivationClean = motivationNA.drop(['id'], axis = 1)
motivationClean

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>motivation1</th>
      <th>motivation2</th>
      <th>motivation3</th>
      <th>motivation4</th>
      <th>motivation5</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2</td>
      <td>1.0</td>
      <td>2</td>
      <td>1.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>2</td>
      <td>3.0</td>
      <td>2</td>
      <td>3.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>3</td>
      <td>2.0</td>
      <td>3</td>
      <td>2.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>21</th>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>24</th>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>25</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>26</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>27</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>28</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>29</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>30</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>31</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>32</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>33</th>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>34</th>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>2.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
motivationkmeans2 = KMeans(n_clusters=2)
motivationkmeans2.fit(motivationClean)
cluster_motivation2 = motivationkmeans2.predict(motivationClean)
```


```python
silhouette_visualizer(motivationkmeans2, motivationClean, colors='yellowbrick')

silhouetteScore2 = silhouette_score(motivationClean, cluster_motivation2, metric='euclidean')

print('Silhouetter Score:', silhouetteScore2)
```


    
![png](output_15_0.png)
    


    Silhouetter Score: 0.4278253443934091
    


```python
motivationkmeans3 = KMeans(n_clusters=3)
motivationkmeans3.fit(motivationClean)
cluster_motivation3 = motivationkmeans3.predict(motivationClean)
silhouette_visualizer(motivationkmeans3, motivationClean, colors='yellowbrick')
silhouetteScore3 = silhouette_score(motivationClean, cluster_motivation3, metric='euclidean')
print('Silhouetter Score:', silhouetteScore3)
```


    
![png](output_16_0.png)
    


    Silhouetter Score: 0.4995840033521631
    


```python
motivationkmeans4 = KMeans(n_clusters=4)
motivationkmeans4.fit(motivationClean)
cluster_motivation4 = motivationkmeans4.predict(motivationClean)
silhouette_visualizer(motivationkmeans4, motivationClean, colors='yellowbrick')
silhouetteScore4 = silhouette_score(motivationClean, cluster_motivation4, metric='euclidean')
print('Silhouetter Score:', silhouetteScore4)
```


    
![png](output_17_0.png)
    


    Silhouetter Score: 0.4939757511461826
    


```python
motivation3cluster = motivationClean.copy(deep=True)

motivation3cluster['cluster'] = cluster_motivation3

motivation3cluster
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>motivation1</th>
      <th>motivation2</th>
      <th>motivation3</th>
      <th>motivation4</th>
      <th>motivation5</th>
      <th>cluster</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2</td>
      <td>1.0</td>
      <td>2</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>13</th>
      <td>2</td>
      <td>3.0</td>
      <td>2</td>
      <td>3.0</td>
      <td>1.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>4.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>3.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>17</th>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>18</th>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>19</th>
      <td>3</td>
      <td>2.0</td>
      <td>3</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>21</th>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>5.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>24</th>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>25</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>4.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>26</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>3.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>27</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>4.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>28</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>3.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>4.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>30</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>3.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>31</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>4.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>32</th>
      <td>1</td>
      <td>2.0</td>
      <td>1</td>
      <td>2.0</td>
      <td>3.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>33</th>
      <td>1</td>
      <td>1.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>34</th>
      <td>2</td>
      <td>2.0</td>
      <td>2</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>


