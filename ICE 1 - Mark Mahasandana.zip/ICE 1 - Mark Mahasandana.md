```python
from emoji import emojize # This line is telling Python to import an object
                          #(in this case it is a function) called "emojize" from the module/package "emoji"
                          # In python, you need to import everything you need before using them.
print(emojize(":thumbs_up:")) # And we then call it out. You should see a thumb up. 
                              #If you are getting missing module error, then your package is not successfully installed.
```

    👍
    


```python
import array
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
```


```python
# variables don't need explicit declaration 
var = "Hello World!" # string 
var = 15.5 # float
var = 2 # int
var = True # booLean
var = None

```


```python
l1 = [1, 2, 3]
l2 = list(range(10)) # create 10 numbers. Notice here Python starts the counting from 0 
l3 = [True, "2", 3.0, 4] # Python allows dynamic typing, so we can even create heterogeneous lists 

print(l1)
print(l2)
```

    [1, 2, 3]
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    


```python
type(l1)
```




    list




```python
A = array.array('i', l2) # Notice here array.array() means the array function under the module array.
                         # array is a package that we have loaded previously.
A
```




    array('i', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])




```python
# Create a length-10 integer array filled with zeros
np.zeros(10, dtype=float)

# Create a 3x5 floating-point array filled with ones
np.ones((3,5), dtype=float)

# Create a 3x5 array filled with 3.14
np.full((3, 5), 3.14)

# Create a 3x3 array of random integers in the interval [0,10)
np.random.randint(0, 10, (3, 3))

```




    array([[7, 8, 4],
           [0, 6, 4],
           [0, 7, 3]])




```python
S = pd.Series([1, 2, 3, 4.0])
S
```




    0    1.0
    1    2.0
    2    3.0
    3    4.0
    dtype: float64




```python
pd.DataFrame(np.random.rand(3, 2), ## this is similar to previous np.random.randint(), only the random value is going to be between 0 to 1.
             columns=['foo', 'bar'], # column names
             index=['a', 'b', 'c']) # row names
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>foo</th>
      <th>bar</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>a</th>
      <td>0.393153</td>
      <td>0.918896</td>
    </tr>
    <tr>
      <th>b</th>
      <td>0.183865</td>
      <td>0.984893</td>
    </tr>
    <tr>
      <th>c</th>
      <td>0.208951</td>
      <td>0.102283</td>
    </tr>
  </tbody>
</table>
</div>




```python
import os
path = os.getcwd()
print(path)

```

    C:\Users\Sivakon.M
    


```python
ICEdata = pd.read_csv("ICE1_Data.csv")
ICEdata
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DBN</th>
      <th>Quality_Review_Score</th>
      <th>Progress_Rpt_10-11</th>
      <th>Student_Progress_10-11</th>
      <th>graduation 2010-11</th>
      <th>college enroll 2010-11</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01M292</td>
      <td>Developing</td>
      <td>C</td>
      <td>C</td>
      <td>0.563</td>
      <td>0.519</td>
    </tr>
    <tr>
      <th>1</th>
      <td>01M448</td>
      <td>Developing</td>
      <td>C</td>
      <td>B</td>
      <td>0.707</td>
      <td>0.363</td>
    </tr>
    <tr>
      <th>2</th>
      <td>01M450</td>
      <td>Well Developed</td>
      <td>A</td>
      <td>B</td>
      <td>0.716</td>
      <td>0.692</td>
    </tr>
    <tr>
      <th>3</th>
      <td>01M509</td>
      <td>Proficient</td>
      <td>C</td>
      <td>C</td>
      <td>0.564</td>
      <td>0.477</td>
    </tr>
    <tr>
      <th>4</th>
      <td>01M539</td>
      <td>Proficient</td>
      <td>A</td>
      <td>A</td>
      <td>0.953</td>
      <td>0.870</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>417</th>
      <td>10X696</td>
      <td>Well Developed</td>
      <td>A</td>
      <td>A</td>
      <td>1.000</td>
      <td>0.936</td>
    </tr>
    <tr>
      <th>418</th>
      <td>13K430</td>
      <td>Proficient</td>
      <td>B</td>
      <td>B</td>
      <td>0.977</td>
      <td>0.867</td>
    </tr>
    <tr>
      <th>419</th>
      <td>10X445</td>
      <td>Well Developed</td>
      <td>A</td>
      <td>A</td>
      <td>1.000</td>
      <td>0.994</td>
    </tr>
    <tr>
      <th>420</th>
      <td>14K449</td>
      <td>Well Developed</td>
      <td>B</td>
      <td>B</td>
      <td>0.914</td>
      <td>0.961</td>
    </tr>
    <tr>
      <th>421</th>
      <td>28Q687</td>
      <td>Proficient</td>
      <td>A</td>
      <td>B</td>
      <td>1.000</td>
      <td>0.972</td>
    </tr>
  </tbody>
</table>
<p>422 rows × 6 columns</p>
</div>




```python
ICEdata.describe(include = 'all')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DBN</th>
      <th>Quality_Review_Score</th>
      <th>Progress_Rpt_10-11</th>
      <th>Student_Progress_10-11</th>
      <th>graduation 2010-11</th>
      <th>college enroll 2010-11</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>422</td>
      <td>368</td>
      <td>310</td>
      <td>310</td>
      <td>310.000000</td>
      <td>291.000000</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>422</td>
      <td>6</td>
      <td>5</td>
      <td>5</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>top</th>
      <td>19K683</td>
      <td>Proficient</td>
      <td>A</td>
      <td>C</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>1</td>
      <td>186</td>
      <td>109</td>
      <td>93</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.737977</td>
      <td>0.531196</td>
    </tr>
    <tr>
      <th>std</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.143356</td>
      <td>0.193129</td>
    </tr>
    <tr>
      <th>min</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.412000</td>
      <td>0.141000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.625250</td>
      <td>0.391000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.726000</td>
      <td>0.489000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.850750</td>
      <td>0.656000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(ICEdata['Quality_Review_Score'].unique())
```

    ['Developing' 'Well Developed' 'Proficient' nan 'Underdeveloped'
     'Outstanding (only an option in 2007-8)'
     'Underdeveloped with Proficient Features (only an option in 2007-8, 2008-9 and 2009-10)']
    


```python
ICEdata['Quality_Review_Score'].value_counts()
```




    Proficient                                                                                186
    Well Developed                                                                            108
    Developing                                                                                 64
    Underdeveloped                                                                              6
    Outstanding (only an option in 2007-8)                                                      3
    Underdeveloped with Proficient Features (only an option in 2007-8, 2008-9 and 2009-10)      1
    Name: Quality_Review_Score, dtype: int64




```python
qualityEnroll = graduationEnroll = ICEdata[['Quality_Review_Score', 'graduation 2010-11', 'college enroll 2010-11']]
qualityEnroll
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Quality_Review_Score</th>
      <th>graduation 2010-11</th>
      <th>college enroll 2010-11</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Developing</td>
      <td>0.563</td>
      <td>0.519</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Developing</td>
      <td>0.707</td>
      <td>0.363</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Well Developed</td>
      <td>0.716</td>
      <td>0.692</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Proficient</td>
      <td>0.564</td>
      <td>0.477</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Proficient</td>
      <td>0.953</td>
      <td>0.870</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>417</th>
      <td>Well Developed</td>
      <td>1.000</td>
      <td>0.936</td>
    </tr>
    <tr>
      <th>418</th>
      <td>Proficient</td>
      <td>0.977</td>
      <td>0.867</td>
    </tr>
    <tr>
      <th>419</th>
      <td>Well Developed</td>
      <td>1.000</td>
      <td>0.994</td>
    </tr>
    <tr>
      <th>420</th>
      <td>Well Developed</td>
      <td>0.914</td>
      <td>0.961</td>
    </tr>
    <tr>
      <th>421</th>
      <td>Proficient</td>
      <td>1.000</td>
      <td>0.972</td>
    </tr>
  </tbody>
</table>
<p>422 rows × 3 columns</p>
</div>




```python
graduationEnroll.plot.scatter(x = 'graduation 2010-11', y = 'college enroll 2010-11')
```




    <AxesSubplot:xlabel='graduation 2010-11', ylabel='college enroll 2010-11'>




    
![png](output_15_1.png)
    



```python
graduationEnroll['college enroll 2010-11'].plot.hist()
```

Add my site note - Title, Explaination More readable 
