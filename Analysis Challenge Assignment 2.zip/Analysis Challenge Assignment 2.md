```python
import pandas as pd
import matplotlib.pyplot as plt
```


```python
tdata = pd.read_csv("AC2_T_Data.csv")
tdata
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>GRADE</th>
      <th>Gender</th>
      <th>ONTASK</th>
      <th>NumACTIVITIES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>1</td>
      <td>Y</td>
      <td>2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>1</td>
      <td>Y</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0</td>
      <td>Y</td>
      <td>4</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0</td>
      <td>Y</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>1</td>
      <td>Y</td>
      <td>3</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>22179</th>
      <td>0</td>
      <td>1</td>
      <td>Y</td>
      <td>3</td>
    </tr>
    <tr>
      <th>22180</th>
      <td>0</td>
      <td>0</td>
      <td>N</td>
      <td>4</td>
    </tr>
    <tr>
      <th>22181</th>
      <td>4</td>
      <td>0</td>
      <td>N</td>
      <td>2</td>
    </tr>
    <tr>
      <th>22182</th>
      <td>0</td>
      <td>1</td>
      <td>Y</td>
      <td>2</td>
    </tr>
    <tr>
      <th>22183</th>
      <td>4</td>
      <td>0</td>
      <td>Y</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>22184 rows × 4 columns</p>
</div>



I start out by extracting unnecessary information from the dataset. At the end, I keep Grade, Gender, ONTASK, and NumACTIVITIES on my table.


```python
tdata['ONTASK'].value_counts()
```




    Y    14938
    N     7246
    Name: ONTASK, dtype: int64



Based on, the dataset, there are 14,938 on-task behaviors and 7,246 off-task behaviors


```python
tdata.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>GRADE</th>
      <th>Gender</th>
      <th>NumACTIVITIES</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>22184.000000</td>
      <td>22184.000000</td>
      <td>22184.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2.056076</td>
      <td>0.506446</td>
      <td>3.383114</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.503220</td>
      <td>0.499970</td>
      <td>1.315163</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>4.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>7.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
dummy = pd.get_dummies(tdata['ONTASK'], prefix = 'ONTASK') 
dummy
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ONTASK_N</th>
      <th>ONTASK_Y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>22179</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>22180</th>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>22181</th>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>22182</th>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>22183</th>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>22184 rows × 2 columns</p>
</div>



I set ONTASK column as dummy. This is to change Y (Yes) and N (No) to numbers.


```python
tdataD = pd.concat([tdata, dummy], axis=1)
tdataD = tdataD.drop(['ONTASK', 'ONTASK_N'], axis=1)
tdataD
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>GRADE</th>
      <th>Gender</th>
      <th>NumACTIVITIES</th>
      <th>ONTASK_Y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0</td>
      <td>6</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>22179</th>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>22180</th>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
    </tr>
    <tr>
      <th>22181</th>
      <td>4</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>22182</th>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>22183</th>
      <td>4</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>22184 rows × 4 columns</p>
</div>



Then, I combine two set of ONTASK together. In this case, I decided to keep ONTASK_Y.


```python
tdata['GRADE'].value_counts()
```




    4    6457
    2    5003
    0    4548
    1    4375
    3    1801
    Name: GRADE, dtype: int64



There are 5 grade types. Grade 4 has the highest number of participants


```python
tdata.shape
```




    (22184, 4)



The shape of data is quite massive with 22,184 rows and 4 columns, which is quite an extensive dataset.


```python
from sklearn.tree import DecisionTreeClassifier

Xs_tree = tdata.drop('ONTASK', axis = 1)
ONTASK = tdata['ONTASK']
```

This is to create a Decision Tree


```python
tdataTreeModel = DecisionTreeClassifier()
tdataTreeModel.fit(Xs_tree, ONTASK)
```




    DecisionTreeClassifier()




```python
from sklearn import tree
text_representation = tree.export_text(tdataTreeModel)
print(text_representation)
```

    |--- feature_0 <= 3.50
    |   |--- feature_2 <= 3.50
    |   |   |--- feature_1 <= 0.50
    |   |   |   |--- feature_0 <= 0.50
    |   |   |   |   |--- feature_2 <= 1.50
    |   |   |   |   |   |--- class: Y
    |   |   |   |   |--- feature_2 >  1.50
    |   |   |   |   |   |--- feature_2 <= 2.50
    |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |--- feature_2 >  2.50
    |   |   |   |   |   |   |--- class: Y
    |   |   |   |--- feature_0 >  0.50
    |   |   |   |   |--- feature_0 <= 1.50
    |   |   |   |   |   |--- feature_2 <= 2.50
    |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |--- feature_2 >  2.50
    |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |--- feature_0 >  1.50
    |   |   |   |   |   |--- feature_2 <= 2.50
    |   |   |   |   |   |   |--- feature_2 <= 1.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |   |--- feature_2 >  1.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |--- feature_2 >  2.50
    |   |   |   |   |   |   |--- feature_0 <= 2.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |   |--- feature_0 >  2.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |--- feature_1 >  0.50
    |   |   |   |--- feature_2 <= 1.50
    |   |   |   |   |--- feature_0 <= 1.00
    |   |   |   |   |   |--- class: Y
    |   |   |   |   |--- feature_0 >  1.00
    |   |   |   |   |   |--- class: Y
    |   |   |   |--- feature_2 >  1.50
    |   |   |   |   |--- feature_0 <= 0.50
    |   |   |   |   |   |--- feature_2 <= 2.50
    |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |--- feature_2 >  2.50
    |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |--- feature_0 >  0.50
    |   |   |   |   |   |--- feature_0 <= 2.50
    |   |   |   |   |   |   |--- feature_0 <= 1.50
    |   |   |   |   |   |   |   |--- feature_2 <= 2.50
    |   |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |   |   |--- feature_2 >  2.50
    |   |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |   |--- feature_0 >  1.50
    |   |   |   |   |   |   |   |--- feature_2 <= 2.50
    |   |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |   |   |--- feature_2 >  2.50
    |   |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |--- feature_0 >  2.50
    |   |   |   |   |   |   |--- class: Y
    |   |--- feature_2 >  3.50
    |   |   |--- feature_1 <= 0.50
    |   |   |   |--- feature_0 <= 0.50
    |   |   |   |   |--- feature_2 <= 6.50
    |   |   |   |   |   |--- feature_2 <= 4.50
    |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |--- feature_2 >  4.50
    |   |   |   |   |   |   |--- feature_2 <= 5.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |   |--- feature_2 >  5.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |--- feature_2 >  6.50
    |   |   |   |   |   |--- class: Y
    |   |   |   |--- feature_0 >  0.50
    |   |   |   |   |--- feature_0 <= 2.50
    |   |   |   |   |   |--- feature_2 <= 5.50
    |   |   |   |   |   |   |--- feature_2 <= 4.50
    |   |   |   |   |   |   |   |--- feature_0 <= 1.50
    |   |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |   |   |--- feature_0 >  1.50
    |   |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |   |--- feature_2 >  4.50
    |   |   |   |   |   |   |   |--- feature_0 <= 1.50
    |   |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |   |   |--- feature_0 >  1.50
    |   |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |--- feature_2 >  5.50
    |   |   |   |   |   |   |--- feature_0 <= 1.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |   |--- feature_0 >  1.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |--- feature_0 >  2.50
    |   |   |   |   |   |--- feature_2 <= 4.50
    |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |--- feature_2 >  4.50
    |   |   |   |   |   |   |--- class: Y
    |   |   |--- feature_1 >  0.50
    |   |   |   |--- feature_0 <= 1.50
    |   |   |   |   |--- feature_2 <= 5.50
    |   |   |   |   |   |--- feature_0 <= 0.50
    |   |   |   |   |   |   |--- feature_2 <= 4.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |   |--- feature_2 >  4.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |--- feature_0 >  0.50
    |   |   |   |   |   |   |--- feature_2 <= 4.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |   |--- feature_2 >  4.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |--- feature_2 >  5.50
    |   |   |   |   |   |--- feature_0 <= 0.50
    |   |   |   |   |   |   |--- feature_2 <= 6.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |   |--- feature_2 >  6.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |--- feature_0 >  0.50
    |   |   |   |   |   |   |--- class: Y
    |   |   |   |--- feature_0 >  1.50
    |   |   |   |   |--- feature_2 <= 5.50
    |   |   |   |   |   |--- feature_2 <= 4.50
    |   |   |   |   |   |   |--- feature_0 <= 2.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |   |--- feature_0 >  2.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |--- feature_2 >  4.50
    |   |   |   |   |   |   |--- feature_0 <= 2.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |   |   |--- feature_0 >  2.50
    |   |   |   |   |   |   |   |--- class: Y
    |   |   |   |   |--- feature_2 >  5.50
    |   |   |   |   |   |--- class: Y
    |--- feature_0 >  3.50
    |   |--- feature_2 <= 4.50
    |   |   |--- feature_2 <= 2.50
    |   |   |   |--- feature_1 <= 0.50
    |   |   |   |   |--- feature_2 <= 1.50
    |   |   |   |   |   |--- class: Y
    |   |   |   |   |--- feature_2 >  1.50
    |   |   |   |   |   |--- class: Y
    |   |   |   |--- feature_1 >  0.50
    |   |   |   |   |--- feature_2 <= 1.50
    |   |   |   |   |   |--- class: Y
    |   |   |   |   |--- feature_2 >  1.50
    |   |   |   |   |   |--- class: Y
    |   |   |--- feature_2 >  2.50
    |   |   |   |--- feature_2 <= 3.50
    |   |   |   |   |--- feature_1 <= 0.50
    |   |   |   |   |   |--- class: Y
    |   |   |   |   |--- feature_1 >  0.50
    |   |   |   |   |   |--- class: Y
    |   |   |   |--- feature_2 >  3.50
    |   |   |   |   |--- feature_1 <= 0.50
    |   |   |   |   |   |--- class: Y
    |   |   |   |   |--- feature_1 >  0.50
    |   |   |   |   |   |--- class: Y
    |   |--- feature_2 >  4.50
    |   |   |--- feature_1 <= 0.50
    |   |   |   |--- class: Y
    |   |   |--- feature_1 >  0.50
    |   |   |   |--- class: Y
    
    


```python
tree.plot_tree(tdataTreeModel)
```




    [Text(214.48125, 205.35999999999999, 'X[0] <= 3.5\ngini = 0.44\nsamples = 22184\nvalue = [7246, 14938]'),
     Text(118.0767857142857, 181.2, 'X[2] <= 3.5\ngini = 0.428\nsamples = 15727\nvalue = [4884, 10843]'),
     Text(50.546103896103894, 157.04, 'X[1] <= 0.5\ngini = 0.441\nsamples = 8470\nvalue = [2777, 5693]'),
     Text(25.0012987012987, 132.88, 'X[0] <= 0.5\ngini = 0.455\nsamples = 4166\nvalue = [1455, 2711]'),
     Text(8.696103896103896, 108.72, 'X[2] <= 1.5\ngini = 0.415\nsamples = 691\nvalue = [203, 488]'),
     Text(4.348051948051948, 84.56, 'gini = 0.423\nsamples = 181\nvalue = [55, 126]'),
     Text(13.044155844155844, 84.56, 'X[2] <= 2.5\ngini = 0.412\nsamples = 510\nvalue = [148, 362]'),
     Text(8.696103896103896, 60.400000000000006, 'gini = 0.411\nsamples = 180\nvalue = [52, 128]'),
     Text(17.392207792207792, 60.400000000000006, 'gini = 0.413\nsamples = 330\nvalue = [96, 234]'),
     Text(41.3064935064935, 108.72, 'X[0] <= 1.5\ngini = 0.461\nsamples = 3475\nvalue = [1252, 2223]'),
     Text(30.436363636363637, 84.56, 'X[2] <= 2.5\ngini = 0.476\nsamples = 1096\nvalue = [429, 667]'),
     Text(26.088311688311688, 60.400000000000006, 'gini = 0.49\nsamples = 311\nvalue = [134, 177]'),
     Text(34.784415584415584, 60.400000000000006, 'gini = 0.469\nsamples = 785\nvalue = [295, 490]'),
     Text(52.176623376623375, 84.56, 'X[2] <= 2.5\ngini = 0.453\nsamples = 2379\nvalue = [823, 1556]'),
     Text(43.480519480519476, 60.400000000000006, 'X[2] <= 1.5\ngini = 0.465\nsamples = 949\nvalue = [349, 600]'),
     Text(39.13246753246753, 36.24000000000001, 'gini = 0.444\nsamples = 132\nvalue = [44, 88]'),
     Text(47.82857142857143, 36.24000000000001, 'gini = 0.468\nsamples = 817\nvalue = [305, 512]'),
     Text(60.872727272727275, 60.400000000000006, 'X[0] <= 2.5\ngini = 0.443\nsamples = 1430\nvalue = [474, 956]'),
     Text(56.52467532467532, 36.24000000000001, 'gini = 0.444\nsamples = 966\nvalue = [321, 645]'),
     Text(65.22077922077922, 36.24000000000001, 'gini = 0.442\nsamples = 464\nvalue = [153, 311]'),
     Text(76.0909090909091, 132.88, 'X[2] <= 1.5\ngini = 0.426\nsamples = 4304\nvalue = [1322, 2982]'),
     Text(65.22077922077922, 108.72, 'X[0] <= 1.0\ngini = 0.459\nsamples = 347\nvalue = [124, 223]'),
     Text(60.872727272727275, 84.56, 'gini = 0.436\nsamples = 259\nvalue = [83, 176]'),
     Text(69.56883116883117, 84.56, 'gini = 0.498\nsamples = 88\nvalue = [41, 47]'),
     Text(86.96103896103895, 108.72, 'X[0] <= 0.5\ngini = 0.422\nsamples = 3957\nvalue = [1198, 2759]'),
     Text(78.26493506493506, 84.56, 'X[2] <= 2.5\ngini = 0.392\nsamples = 691\nvalue = [185, 506]'),
     Text(73.91688311688311, 60.400000000000006, 'gini = 0.403\nsamples = 279\nvalue = [78, 201]'),
     Text(82.612987012987, 60.400000000000006, 'gini = 0.385\nsamples = 412\nvalue = [107, 305]'),
     Text(95.65714285714286, 84.56, 'X[0] <= 2.5\ngini = 0.428\nsamples = 3266\nvalue = [1013, 2253]'),
     Text(91.30909090909091, 60.400000000000006, 'X[0] <= 1.5\ngini = 0.433\nsamples = 2723\nvalue = [863, 1860]'),
     Text(82.612987012987, 36.24000000000001, 'X[2] <= 2.5\ngini = 0.444\nsamples = 843\nvalue = [281, 562]'),
     Text(78.26493506493506, 12.079999999999984, 'gini = 0.39\nsamples = 230\nvalue = [61, 169]'),
     Text(86.96103896103895, 12.079999999999984, 'gini = 0.46\nsamples = 613\nvalue = [220, 393]'),
     Text(100.0051948051948, 36.24000000000001, 'X[2] <= 2.5\ngini = 0.427\nsamples = 1880\nvalue = [582, 1298]'),
     Text(95.65714285714286, 12.079999999999984, 'gini = 0.431\nsamples = 917\nvalue = [288, 629]'),
     Text(104.35324675324675, 12.079999999999984, 'gini = 0.424\nsamples = 963\nvalue = [294, 669]'),
     Text(100.0051948051948, 60.400000000000006, 'gini = 0.4\nsamples = 543\nvalue = [150, 393]'),
     Text(185.60746753246752, 157.04, 'X[1] <= 0.5\ngini = 0.412\nsamples = 7257\nvalue = [2107, 5150]'),
     Text(139.68116883116883, 132.88, 'X[0] <= 0.5\ngini = 0.425\nsamples = 3539\nvalue = [1084, 2455]'),
     Text(117.39740259740259, 108.72, 'X[2] <= 6.5\ngini = 0.409\nsamples = 1315\nvalue = [377, 938]'),
     Text(113.04935064935064, 84.56, 'X[2] <= 4.5\ngini = 0.401\nsamples = 1198\nvalue = [333, 865]'),
     Text(108.7012987012987, 60.400000000000006, 'gini = 0.41\nsamples = 750\nvalue = [216, 534]'),
     Text(117.39740259740259, 60.400000000000006, 'X[2] <= 5.5\ngini = 0.386\nsamples = 448\nvalue = [117, 331]'),
     Text(113.04935064935064, 36.24000000000001, 'gini = 0.376\nsamples = 334\nvalue = [84, 250]'),
     Text(121.74545454545455, 36.24000000000001, 'gini = 0.411\nsamples = 114\nvalue = [33, 81]'),
     Text(121.74545454545455, 84.56, 'gini = 0.469\nsamples = 117\nvalue = [44, 73]'),
     Text(161.96493506493505, 108.72, 'X[0] <= 2.5\ngini = 0.434\nsamples = 2224\nvalue = [707, 1517]'),
     Text(150.0077922077922, 84.56, 'X[2] <= 5.5\ngini = 0.441\nsamples = 1833\nvalue = [603, 1230]'),
     Text(139.13766233766233, 60.400000000000006, 'X[2] <= 4.5\ngini = 0.449\nsamples = 1204\nvalue = [409, 795]'),
     Text(130.44155844155844, 36.24000000000001, 'X[0] <= 1.5\ngini = 0.439\nsamples = 937\nvalue = [305, 632]'),
     Text(126.0935064935065, 12.079999999999984, 'gini = 0.442\nsamples = 831\nvalue = [274, 557]'),
     Text(134.78961038961037, 12.079999999999984, 'gini = 0.414\nsamples = 106\nvalue = [31, 75]'),
     Text(147.83376623376623, 36.24000000000001, 'X[0] <= 1.5\ngini = 0.476\nsamples = 267\nvalue = [104, 163]'),
     Text(143.4857142857143, 12.079999999999984, 'gini = 0.43\nsamples = 131\nvalue = [41, 90]'),
     Text(152.1818181818182, 12.079999999999984, 'gini = 0.497\nsamples = 136\nvalue = [63, 73]'),
     Text(160.87792207792208, 60.400000000000006, 'X[0] <= 1.5\ngini = 0.427\nsamples = 629\nvalue = [194, 435]'),
     Text(156.52987012987012, 36.24000000000001, 'gini = 0.428\nsamples = 296\nvalue = [92, 204]'),
     Text(165.225974025974, 36.24000000000001, 'gini = 0.425\nsamples = 333\nvalue = [102, 231]'),
     Text(173.9220779220779, 84.56, 'X[2] <= 4.5\ngini = 0.39\nsamples = 391\nvalue = [104, 287]'),
     Text(169.57402597402597, 60.400000000000006, 'gini = 0.442\nsamples = 97\nvalue = [32, 65]'),
     Text(178.27012987012986, 60.400000000000006, 'gini = 0.37\nsamples = 294\nvalue = [72, 222]'),
     Text(231.53376623376622, 132.88, 'X[0] <= 1.5\ngini = 0.399\nsamples = 3718\nvalue = [1023, 2695]'),
     Text(210.88051948051947, 108.72, 'X[2] <= 5.5\ngini = 0.41\nsamples = 2770\nvalue = [796, 1974]'),
     Text(195.66233766233765, 84.56, 'X[0] <= 0.5\ngini = 0.405\nsamples = 2325\nvalue = [657, 1668]'),
     Text(186.96623376623376, 60.400000000000006, 'X[2] <= 4.5\ngini = 0.395\nsamples = 1398\nvalue = [378, 1020]'),
     Text(182.61818181818182, 36.24000000000001, 'gini = 0.392\nsamples = 1070\nvalue = [286, 784]'),
     Text(191.31428571428572, 36.24000000000001, 'gini = 0.404\nsamples = 328\nvalue = [92, 236]'),
     Text(204.35844155844154, 60.400000000000006, 'X[2] <= 4.5\ngini = 0.421\nsamples = 927\nvalue = [279, 648]'),
     Text(200.0103896103896, 36.24000000000001, 'gini = 0.435\nsamples = 771\nvalue = [247, 524]'),
     Text(208.7064935064935, 36.24000000000001, 'gini = 0.326\nsamples = 156\nvalue = [32, 124]'),
     Text(226.0987012987013, 84.56, 'X[0] <= 0.5\ngini = 0.43\nsamples = 445\nvalue = [139, 306]'),
     Text(221.75064935064935, 60.400000000000006, 'X[2] <= 6.5\ngini = 0.467\nsamples = 194\nvalue = [72, 122]'),
     Text(217.4025974025974, 36.24000000000001, 'gini = 0.49\nsamples = 105\nvalue = [45, 60]'),
     Text(226.0987012987013, 36.24000000000001, 'gini = 0.423\nsamples = 89\nvalue = [27, 62]'),
     Text(230.44675324675325, 60.400000000000006, 'gini = 0.391\nsamples = 251\nvalue = [67, 184]'),
     Text(252.187012987013, 108.72, 'X[2] <= 5.5\ngini = 0.364\nsamples = 948\nvalue = [227, 721]'),
     Text(247.83896103896103, 84.56, 'X[2] <= 4.5\ngini = 0.393\nsamples = 617\nvalue = [166, 451]'),
     Text(239.14285714285714, 60.400000000000006, 'X[0] <= 2.5\ngini = 0.36\nsamples = 276\nvalue = [65, 211]'),
     Text(234.79480519480518, 36.24000000000001, 'gini = 0.347\nsamples = 121\nvalue = [27, 94]'),
     Text(243.4909090909091, 36.24000000000001, 'gini = 0.37\nsamples = 155\nvalue = [38, 117]'),
     Text(256.53506493506495, 60.400000000000006, 'X[0] <= 2.5\ngini = 0.417\nsamples = 341\nvalue = [101, 240]'),
     Text(252.187012987013, 36.24000000000001, 'gini = 0.464\nsamples = 93\nvalue = [34, 59]'),
     Text(260.8831168831169, 36.24000000000001, 'gini = 0.394\nsamples = 248\nvalue = [67, 181]'),
     Text(256.53506493506495, 84.56, 'gini = 0.301\nsamples = 331\nvalue = [61, 270]'),
     Text(310.8857142857143, 181.2, 'X[2] <= 4.5\ngini = 0.464\nsamples = 6457\nvalue = [2362, 4095]'),
     Text(295.66753246753245, 157.04, 'X[2] <= 2.5\ngini = 0.471\nsamples = 5858\nvalue = [2220, 3638]'),
     Text(278.27532467532467, 132.88, 'X[1] <= 0.5\ngini = 0.442\nsamples = 2230\nvalue = [736, 1494]'),
     Text(269.57922077922075, 108.72, 'X[2] <= 1.5\ngini = 0.481\nsamples = 948\nvalue = [381, 567]'),
     Text(265.2311688311688, 84.56, 'gini = 0.476\nsamples = 412\nvalue = [161, 251]'),
     Text(273.92727272727274, 84.56, 'gini = 0.484\nsamples = 536\nvalue = [220, 316]'),
     Text(286.9714285714286, 108.72, 'X[2] <= 1.5\ngini = 0.4\nsamples = 1282\nvalue = [355, 927]'),
     Text(282.6233766233766, 84.56, 'gini = 0.414\nsamples = 475\nvalue = [139, 336]'),
     Text(291.3194805194805, 84.56, 'gini = 0.392\nsamples = 807\nvalue = [216, 591]'),
     Text(313.05974025974024, 132.88, 'X[2] <= 3.5\ngini = 0.483\nsamples = 3628\nvalue = [1484, 2144]'),
     Text(304.3636363636364, 108.72, 'X[1] <= 0.5\ngini = 0.479\nsamples = 1611\nvalue = [639, 972]'),
     Text(300.0155844155844, 84.56, 'gini = 0.485\nsamples = 902\nvalue = [373, 529]'),
     Text(308.7116883116883, 84.56, 'gini = 0.469\nsamples = 709\nvalue = [266, 443]'),
     Text(321.75584415584416, 108.72, 'X[1] <= 0.5\ngini = 0.487\nsamples = 2017\nvalue = [845, 1172]'),
     Text(317.4077922077922, 84.56, 'gini = 0.489\nsamples = 1017\nvalue = [432, 585]'),
     Text(326.1038961038961, 84.56, 'gini = 0.485\nsamples = 1000\nvalue = [413, 587]'),
     Text(326.1038961038961, 157.04, 'X[1] <= 0.5\ngini = 0.362\nsamples = 599\nvalue = [142, 457]'),
     Text(321.75584415584416, 132.88, 'gini = 0.358\nsamples = 377\nvalue = [88, 289]'),
     Text(330.451948051948, 132.88, 'gini = 0.368\nsamples = 222\nvalue = [54, 168]')]




    
![png](output_18_1.png)
    


Since, it is a large dataset, this is why the decision tree looks very massive. At this point the tree looks pretty complicate and difficult to justify. Therefore, I decided to use Naive Bayes as an alternative method to predict the data's accuracy. 


```python
from sklearn.naive_bayes import GaussianNB

Xs_NB = tdata.drop('ONTASK', axis = 1)
ONTASK = tdata['ONTASK']
```


```python
tdataNBModel = GaussianNB()
tdataNBModel.fit(Xs_NB, ONTASK)
```




    GaussianNB()




```python
ONTASK_pred = tdataNBModel.predict(Xs_NB)
performance = [item in ONTASK_pred for item in ONTASK]
print('The accuracy is', sum(performance)/len(performance)*100, '%')
```

    The accuracy is 67.3368193292463 %
    

The accuracy is 67.3%, which is not so accurate. 

Author - Mark Mahasandana
