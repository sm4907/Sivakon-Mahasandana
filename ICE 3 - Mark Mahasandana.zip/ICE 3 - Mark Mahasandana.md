```python
from sklearn.linear_model import LinearRegression
import pandas as pd
import matplotlib.pyplot as plt
```


```python
school = pd.read_csv("ICE1_Data.csv")
graduationCollege = school[['graduation 2010-11', 'college enroll 2010-11']].dropna()
graduation = graduationCollege.loc[:,"graduation 2010-11"].values.reshape(-1, 1)
college = graduationCollege.loc[:,"college enroll 2010-11"].values.reshape(-1, 1)

graduationCollege.plot.scatter(x = 'graduation 2010-11', y = 'college enroll 2010-11')
```




    <AxesSubplot:xlabel='graduation 2010-11', ylabel='college enroll 2010-11'>




    
![png](output_1_1.png)
    



```python
model = LinearRegression()
model.fit(graduation, college)
print("The intercept is: ", model.intercept_)
print("The slope is: ", model.coef_)
```

    The intercept is:  [-0.27965123]
    The slope is:  [[1.09914898]]
    


```python
college_pred = model.predict(graduation)
```


```python
plt.scatter(graduation, college)
plt.plot(graduation, college_pred, color = 'red')
plt.show()
```


    
![png](output_4_0.png)
    



```python
videoData = pd.read_csv("ICE3_data.csv")
videoData
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>stid</th>
      <th>year</th>
      <th>video</th>
      <th>participation</th>
      <th>watch.time</th>
      <th>confusion.points</th>
      <th>key.points</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>2018</td>
      <td>A</td>
      <td>1</td>
      <td>16.5</td>
      <td>6</td>
      <td>6</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2018</td>
      <td>A</td>
      <td>0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>2018</td>
      <td>A</td>
      <td>1</td>
      <td>9.0</td>
      <td>4</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>2018</td>
      <td>A</td>
      <td>1</td>
      <td>20.0</td>
      <td>8</td>
      <td>5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>2018</td>
      <td>A</td>
      <td>1</td>
      <td>12.0</td>
      <td>8</td>
      <td>5</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>295</th>
      <td>56</td>
      <td>2019</td>
      <td>E</td>
      <td>1</td>
      <td>12.0</td>
      <td>6</td>
      <td>2</td>
    </tr>
    <tr>
      <th>296</th>
      <td>57</td>
      <td>2019</td>
      <td>E</td>
      <td>1</td>
      <td>17.5</td>
      <td>10</td>
      <td>1</td>
    </tr>
    <tr>
      <th>297</th>
      <td>58</td>
      <td>2019</td>
      <td>E</td>
      <td>1</td>
      <td>6.0</td>
      <td>4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>298</th>
      <td>59</td>
      <td>2019</td>
      <td>E</td>
      <td>0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>299</th>
      <td>60</td>
      <td>2019</td>
      <td>E</td>
      <td>0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>300 rows × 7 columns</p>
</div>




```python
videoData.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>stid</th>
      <th>year</th>
      <th>participation</th>
      <th>watch.time</th>
      <th>confusion.points</th>
      <th>key.points</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>300.000000</td>
      <td>300.000000</td>
      <td>300.000000</td>
      <td>300.000000</td>
      <td>300.000000</td>
      <td>300.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>30.500000</td>
      <td>2018.500000</td>
      <td>0.743333</td>
      <td>9.302500</td>
      <td>4.426667</td>
      <td>2.326667</td>
    </tr>
    <tr>
      <th>std</th>
      <td>17.347038</td>
      <td>0.500835</td>
      <td>0.437524</td>
      <td>8.396475</td>
      <td>3.606658</td>
      <td>1.921526</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>2018.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>15.750000</td>
      <td>2018.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>30.500000</td>
      <td>2018.500000</td>
      <td>1.000000</td>
      <td>8.375000</td>
      <td>5.000000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>45.250000</td>
      <td>2019.000000</td>
      <td>1.000000</td>
      <td>15.750000</td>
      <td>8.000000</td>
      <td>4.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>60.000000</td>
      <td>2019.000000</td>
      <td>1.000000</td>
      <td>32.500000</td>
      <td>13.000000</td>
      <td>7.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.plotting.scatter_matrix(videoData.iloc[:,3:])
```




    array([[<AxesSubplot:xlabel='participation', ylabel='participation'>,
            <AxesSubplot:xlabel='watch.time', ylabel='participation'>,
            <AxesSubplot:xlabel='confusion.points', ylabel='participation'>,
            <AxesSubplot:xlabel='key.points', ylabel='participation'>],
           [<AxesSubplot:xlabel='participation', ylabel='watch.time'>,
            <AxesSubplot:xlabel='watch.time', ylabel='watch.time'>,
            <AxesSubplot:xlabel='confusion.points', ylabel='watch.time'>,
            <AxesSubplot:xlabel='key.points', ylabel='watch.time'>],
           [<AxesSubplot:xlabel='participation', ylabel='confusion.points'>,
            <AxesSubplot:xlabel='watch.time', ylabel='confusion.points'>,
            <AxesSubplot:xlabel='confusion.points', ylabel='confusion.points'>,
            <AxesSubplot:xlabel='key.points', ylabel='confusion.points'>],
           [<AxesSubplot:xlabel='participation', ylabel='key.points'>,
            <AxesSubplot:xlabel='watch.time', ylabel='key.points'>,
            <AxesSubplot:xlabel='confusion.points', ylabel='key.points'>,
            <AxesSubplot:xlabel='key.points', ylabel='key.points'>]],
          dtype=object)




    
![png](output_7_1.png)
    



```python
### Normal Transformation
### Insert Your Code Here ###
```


```python
Xs = videoData[["participation", "confusion.points", "key.points"]].to_numpy()
watchTime = videoData.loc[:,"watch.time"].values.reshape(-1, 1)
```


```python
videoModel = LinearRegression()
videoModel.fit(Xs, watchTime)
print("The intercept is: ", videoModel.intercept_)
print("The slope is: ", videoModel.coef_)
```

    The intercept is:  [3.55271368e-15]
    The slope is:  [[ 0.55757518  2.08731237 -0.15120358]]
    


```python
from statsmodels.api import OLS
videoModelOLS = OLS(watchTime, Xs)
videoModelOLSFit = videoModelOLS.fit()
print(videoModelOLSFit.summary())
```

                                     OLS Regression Results                                
    =======================================================================================
    Dep. Variable:                      y   R-squared (uncentered):                   0.919
    Model:                            OLS   Adj. R-squared (uncentered):              0.918
    Method:                 Least Squares   F-statistic:                              1117.
    Date:                Tue, 19 Oct 2021   Prob (F-statistic):                   2.36e-161
    Time:                        23:35:32   Log-Likelihood:                         -807.73
    No. Observations:                 300   AIC:                                      1621.
    Df Residuals:                     297   BIC:                                      1633.
    Df Model:                           3                                                  
    Covariance Type:            nonrobust                                                  
    ==============================================================================
                     coef    std err          t      P>|t|      [0.025      0.975]
    ------------------------------------------------------------------------------
    x1             0.5576      0.844      0.660      0.509      -1.104       2.219
    x2             2.0873      0.086     24.137      0.000       1.917       2.257
    x3            -0.1512      0.160     -0.945      0.345      -0.466       0.164
    ==============================================================================
    Omnibus:                        7.098   Durbin-Watson:                   2.037
    Prob(Omnibus):                  0.029   Jarque-Bera (JB):                7.426
    Skew:                          -0.283   Prob(JB):                       0.0244
    Kurtosis:                       3.523   Cond. No.                         25.8
    ==============================================================================
    
    Notes:
    [1] R² is computed without centering (uncentered) since the model does not contain a constant.
    [2] Standard Errors assume that the covariance matrix of the errors is correctly specified.
    
